# PERF (PERFormance measuring)

Utility for measuring runtime
